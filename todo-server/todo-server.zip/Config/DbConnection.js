const mongoose = require('mongoose');
const dotenv = require('dotenv');
dotenv.config();

mongoose.connect(process.env.DATABASEURL).then(() => {
    console.log('Database connected');
}).catch((error) => {
    console.log(error);
});